#untuk yaml, tinggal pakai modul yaml
import yaml#json
import xmltodict

with open("flowerandbg.xml", 'r') as f:
    xmlString = f.read()
    
print("XML input (flowerandbg.xml) : ")
print(xmlString)

#jsonString = json.dumps (xmltodict.parse(xmlString), indent = 4)
jsonString = yaml.dump (xmltodict.parse(xmlString), indent = 4)

#print("\nJSON output(output.json):")
print("\nYAML output(output.json):")
print(jsonString)

#with open("output.json", 'w') as f:
with open("output.yaml", 'w') as f:
    f.write(jsonString) 