import yaml
import xmltodict

f = open("flowerandbg.xml", "r")
my_xml = f.read()
f.close()
my_dict = xmltodict.parse(my_xml)
#my_yaml = yaml.dumps(my_dict)			#modul yaml tidak memiliki fungsi dumps
my_yaml = yaml.dump(my_dict)			#akan tetapi hanya memiliki fungsi dump
#print(mt_yaml)							#typo
print(my_yaml)	

#tambahan kode:
#simpan my_yaml ke dalam file 
with open("output.yaml", 'w') as f:
    f.write(my_yaml)