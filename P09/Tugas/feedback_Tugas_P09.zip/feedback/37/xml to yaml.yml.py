import xmltodict
import yaml

with open('flowerandbg.xml') as xml_file:
    my_dict=xmltodict.parse(xml_file.read())	#baca file xml dan konversi tipe data dictionary
xml_file.close()
yaml_data=yaml.dump(my_dict)					#konversi dictionary (my_dict) ke string berformat json
print(yaml_data)

#Tambahan kode:
#Simpan yaml_data ke sebuah file
with open("data.yaml", "w") as yaml_file: 
	yaml_file.write(yaml_data) 
	yaml_file.close() 