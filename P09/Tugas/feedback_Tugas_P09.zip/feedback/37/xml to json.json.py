import xmltodict
import json

with open('flowerandbg.xml') as xml_file:		
    my_dict=xmltodict.parse(xml_file.read())	#baca file xml dan konversi tipe data dictionary
xml_file.close()								
json_data=json.dumps(my_dict)					#konversi dictionary (my_dict) ke string berformat json
print(json_data)								

#Tambahan kode:
#Simpan json_data ke sebuah file
with open("data.json", "w") as json_file: 
	json_file.write(json_data) 
	json_file.close() 