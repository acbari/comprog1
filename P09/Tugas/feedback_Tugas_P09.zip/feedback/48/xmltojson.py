import json
import xmltodict
import yaml
 
with open("flowerandbg.xml", 'r') as f:			#untuk meminimalkan pembacaan file
    xmlString = f.read()                        #simpan hasil parsing xmltodic ke sebuah variabel misal dict1
                                                #sehingga dapat langsung di konversi ke format json dan yaml
print("XML input (flowerandbg.xml):")           #tanpa harus membuka file yang sama dua kali
print(xmlString)								#baca file dari harddisk sangat lambat dibanding membaca memory
     
jsonString = json.dumps(xmltodict.parse(xmlString), indent=4)	#dict1 = xmltodict.parse(xmlString)
												#jsonString = json.dumps(dict1, indent=4)
print("\nJSON output(output.json):")		
print(jsonString)
 
with open("output.json", 'w') as f:
    f.write(jsonString)

f = open("flowerandbg.xml").read()				#tidak perlu membuka & membaca file lagi
a = xmltodict.parse(f)							#dan tidak perlu mengkonversi lagi 
yaml.dump(a, open("out.yaml",'w')) 				#yaml.dump(dict1, open("out.yaml",'w'))
	
#kode program dibawah ini tidak diperlukan karena baris kode 19-21 sudah melakukan hal yang sama
f = open ("flowerandbg.xml","r")
xmlstr = f.read()
f.close()
randDict = xmltodict.parse(xmlstr)
yaml_str = yaml.dump(randDict)
print(yaml_str)
