import xmltodict
import json

with open('a.xml') as x:
    a=xmltodict.parse(x.read())
x.close()
b=json.dumps(a)
print(b)

# tulis hasil akhir ke dalam file .json
with open("data.json", "w") as json_file: 
	json_file.write(b) 
	json_file.close() 