import xmltodict
import yaml

with open('a.xml') as x:
    a=xmltodict.parse(x.read())
x.close()
b=yaml.dump(a)
print(b)

# tulis hasil akhir ke dalam file .yaml
with open("data.yaml", "w") as yaml_file: 
	yaml_file.write(b) 
	yaml_file.close() 