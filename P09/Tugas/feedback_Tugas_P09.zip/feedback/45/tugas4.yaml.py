# Program to convert an xml 
# file to json file 

# import json module and xmltodict 
# module provided by python 
import xmltodict 
import yaml


# open the input xml file and read 
# data in form of python dictionary 
# using xmltodict module 
with open("basic.xml") as xml_file: 
	
	data_dict = xmltodict.parse(xml_file.read()) 
	xml_file.close() 
	
	# generate the object using json.dumps() 
	# corresponding to json data 
	
	yaml_data = yaml.dump(data_dict) 
	print(yaml_data)
	# Write the json data to output 
	# json file 
	
	#mana kode untuk menyimpan ke dalam file yaml??
	#tambahan kode
	f=open("data.yaml",'w')
	f.write(yaml_data)
	f.close()