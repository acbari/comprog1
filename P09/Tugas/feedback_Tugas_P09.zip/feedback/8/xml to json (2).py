import xmltodict
import json
 
xml='''<website>
    <name>Coronavirus</name>
    <article>Related to virus</article>
    <message>Stay at home</message>
</website>'''

my_dict=xmltodict.parse(xml)
json_data=json.dumps(my_dict)
print(json_data)