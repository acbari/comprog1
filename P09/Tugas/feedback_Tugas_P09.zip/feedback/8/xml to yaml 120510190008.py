import yaml
import xmltodict

f = open("my_xml.xml", "r")			#
my_xml = f.read()					#
f.close()							#baca file ke string my_xml
my_dict = xmltodict.parse(my_xml)	#konversi my_xml menjadi dictionary my_dict
my_yaml = yaml.dump(my_dict)		#konversi my_dict menjadi format yaml
print(my_yaml)						#tampilkan ke layar

#simpan ke dalam file:
f=open('my_xml.yaml','w')
f.write(my_yaml)
f.close()
#akhir simpan file