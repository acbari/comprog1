import xmltodict
import json

with open('my_xml.xml') as xml_file:			#
    my_dict=xmltodict.parse(xml_file.read())	#baca dan konversi isi file menjadi dictionary (my_dict)
xml_file.close()								#tidak perlu memanggil close() apabila memakai with .. as:
												#karena sudah otomatis ditutup
json_data=json.dumps(my_dict)				#konversi ke format json
print(json_data)							#tampilkan ke layar

#simpan ke dalam file:
f=open('my_xml.json','w')
f.write(json_data)
f.close()
#akhir simpan file