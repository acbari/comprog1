import xmltodict
import yaml

f = open("flowrand.xml").read()		#buka dan baca isi file
a = xmltodict.parse(f)				#konversi XML ke tipe data dictionary
yaml.dump(a, open("out.yaml",'w'))	#konversi dictionary ke format yaml
#kode program cukup sampai sini

#kode program dibaawh ini tidak diperlukan
#karena melakukan hal yang sama, bahkan minus simpan ke dalam file
f = open ("flowrand.xml","r")
xmlstr = f.read()
f.close()							#buka dan baca isi file
randDict = xmltodict.parse(xmlstr)	#konversi XML ke tipe data dictionary
yaml_str = yaml.dump(randDict)		#konversi dictionary ke format yaml
print(yaml_str)