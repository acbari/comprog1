import xmltodict
import json


f = open("flowrand.xml").read()		#baca isi file
a = xmltodict.parse(f)				#konversi format XML ke tipedata dictionary (a)
json.dump(a, open("out.json",'w'))	#konversi dictionary ke format json, dan langung simpan ke file 
#kode program cukup sampai sini

#kode program dibaawh ini tidak diperlukan
#karena melakukan hal yang sama, bahkan minus simpan ke dalam file
f = open ("flowrand.xml","r")			
xmlstr = f.read()
f.close()							#baca isi file 
randDict = xmltodict.parse(xmlstr)	#konversi format XML ke tipe data dictionary (randdict)
json_str = json.dumps(randDict)		#konversi dictionary ke format json
print(json_str)						#tampilkan ke layar


