import xmltodict
import json

xml='''<website>
        <name>Codespeedy</name>
        <article>Related to programming</article>
        <message>You can learn easily from codespeedy</message>
    </website>'''

my_dict=xmltodict.parse(xml)
json_data=json.dumps(my_dict)
print(json_data)

#simpan ke dalam file:
f=open('my_xml.json','w')
f.write(json_data)
f.close()
#akhir simpan file

#program mengalami error ketika dijalankan karena nama program json.py konflik dengan modul import json
#nama file python tidak boleh sama dengan modul yang diimport, karena pada intinya setiap file .py juga adalah modul
#usahakan untuk melakukan re-run program setelah mengubah nama file 