import yaml
import xmltodict

f = open("flowerandbg.xml", "r")
xml = f.read()
f.close()
parse_dict = xmltodict.parse(xml)
#yaml = yaml.dumps(parse_dict)		#versi asli .dumps => tidak dikenali
yaml = yaml.dump(parse_dict)		#karena modul yaml hanya memiliki fungsi .dump
									#berbeda dengan modul json
print(yaml)

#simpan ke dalam file:
f=open('my_xml.yaml','w')
f.write(yaml)
f.close()
#akhir simpan file

#program mengalami error ketika dijalankan karena nama asli program yaml.py konflik dengan modul import yaml
#nama file python tidak boleh sama dengan modul yang diimport, karena pada intinya setiap file .py juga adalah modul
#usahakan untuk melakukan re-run program setelah mengubah nama file 