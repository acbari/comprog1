import yaml
import json
import xmltodict

s = open("flowerandbg.xml").read()
d = xmltodict.parse(s)
yaml.dump(d, open("output1.yaml",'w'))
json.dump(d, open("output2.json",'w'))

#clean & compact, nice!