<website>
    <name>Computer Programming</name>
    <article>Konversi Data</article>
    <message>Konversi data menggunakan python</message>
</website>
<!-- Komentar -->
<!-- file ini seharusnya diberi ekstensi .xml saja ya -->