import xmltodict
import json

#with open('bagian 2.py') as xml_file:			#tolong disertakan juga file xml yang akan dibuka
												#dan gunakan penamaan ekstensi yang standard: .xml bukan .py
with open('flowerandbg.xml') as xml_file:				#untuk pengujian saya ganti dengan file flowerandbg.xml
    my_dict=xmltodict.parse(xml_file.read())	#konversi hasil pembacaan file xml menjadi tipe data dictionary
xml_file.close()
json_data=json.dumps(my_dict)					#konversi tipe data dictionary menjadi string berformat json 
print(json_data)

#note: file ini tidak perlu disubmit mengingat file ini
#melakukan fungsi yang sama dengan file ("XML to JSON(1)-Nasya Anggia-120510190046.py")

#simpan string berformat json ke dalam sebuah file
#tambahan kode
f=open("data.json",'w')
f.write(json_data)
f.close()