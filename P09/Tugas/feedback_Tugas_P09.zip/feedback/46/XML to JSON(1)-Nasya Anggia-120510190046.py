import xmltodict
import json

xml='''<website>
        <name>Computer Programming</name>
        <article>Konversi Data</article>
        <message>Konversi data menggunakan python</message>
    </website>'''

my_dict=xmltodict.parse(xml)	#konversi string berformat xml menjadi tipe data dictionary
json_data=json.dumps(my_dict)	#konversi tipe data dictionary menjadi string berformat json
print(json_data)

#simpan string berformat json ke dalam sebuah file misal data.json
#tambahan kode
f=open("data.json",'w')
f.write(json_data)
f.close()