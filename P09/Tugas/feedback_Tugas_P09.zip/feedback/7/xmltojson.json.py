import xmltodict  
import json

with open("basic.xml") as xml_file: 
	a_dict = xmltodict.parse(xml_file.read()) 
	xml_file.close() 
	
json_data = json.dumps(a_dict) 
print(json_data)
f = open("dict2json.json","w")
f.write(json_data)
f.close()
 
