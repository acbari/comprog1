import xmltodict
import yaml

f = open("basic.xml", "r")
my_xml = f.read()
f.close()
my_dict = xmltodict.parse(my_xml)
my_yaml = yaml.dump(my_dict)

print(my_yaml)

f = open("output_yaml_path",'w')	#biasakan untuk memberi ekstensi standar, .yaml untuk file berformat yaml
f.write(my_yaml)
f.close()