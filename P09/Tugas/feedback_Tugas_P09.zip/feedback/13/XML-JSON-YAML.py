import xmltodict
import json
import yaml
 
with open("data.xml", 'r') as f:
    dataXml = f.read()
 
print("output XML :")
print(dataXml)
     
jsonString = json.dumps(xmltodict.parse(dataXml), indent=2)

 
print("output JSON:")
print(jsonString)
 
with open("output.json", 'w') as f:
    f.write(jsonString)
f.close()

#output YAML
f = open("data.xml").read()
a = xmltodict.parse(f)
yaml.dump(a, open("outputData.yaml",'w'))
#kode konversi ke format yaml selesai sampai disini,
#tersimpan ke dalam file "outputData.yaml"

#kode baris dibawah melakukan hal yang sama dengan kode baris 21-26,
#bahkan minus proses untuk menyimpan ke dalam file
f = open ("data.xml","r")
dataYaml = f.read()
f.close()
yamlDict = xmltodict.parse(dataYaml)
yaml_str = yaml.dump(yamlDict)
print('output YAML :')
print(yaml_str)