import xmltodict
import yaml

f = open("flowerandbg.xml", "r")
my_xml = f.read()
f.close()
my_dict = xmltodict.parse(my_xml)
my_yaml = yaml.dump(my_dict)
print(my_yaml)

#simpan hasil konversi ke dalam file
with open("output.yaml", "w") as f:
    f.write(my_yaml)
#selesai simpan