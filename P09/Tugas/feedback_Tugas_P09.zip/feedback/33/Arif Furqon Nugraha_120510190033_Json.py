import xmltodict

bookstore = {}				#membuat sebuah variabel dengan tipe data dictionary
books = {}
books ["category"] = "bioghraphy"
books ["title"] = "ada apa hari ini den sastro"
books ["author"] = "Soejono Soekanto"
books ["year"] = "2015"
books ["price"] = "78.000"
bookstore["books"] = books
xml_str = xmltodict.unparse(bookstore, pretty=True)	#dan mengkonversinya menjadi string berformat xml
print(xml_str)

f = open ("out.json","w")	
f.write(xml_str)			#xml_str adalah format xml, bukan json
f.close()					#out.json berisi data dengan format xml
							#lebih baik diganti namanya menjadi out.xml
							#file kode dari baris 1 s/d 16 dapat disimpan ke dalam file python terpisah
							#misal: xml_generator.py yang berfungsi untuk menghasilkan file xml
							
f = open ("out.json","r")	#program dapat dimulai dari kode baris ini dengan menghapus kode2 diatas
xmlstr = f.read()			#karena out.json berisi format xml, maka xmlstr merupakan string berformat xml
f.close()

newbookDict = xmltodict.parse(xmlstr)					#konversi string dengan format xml ke tipe dictionary
print(newbookDict["books"])
print(newbookDict["books"]["category"])
print(newbookDict["books"]["title"])
print(newbookDict["books"]["author"])
print(newbookDict["books"]["year"])
print(newbookDict["books"]["price"])
xmlstr = xmltodict.unparse(newbookDict, pretty=True)	#Mengapa tipe dictionary diubah kembali ke format xml??
print(xmlstr)

#tambahan kode:
#1. konversi dictionary (newbookDict) menjadi string berformat json 
import json
json_data = json.dumps(newbookDict)
#2. simpan string berformat json tersebut ke dalam file json
f = open("out.json",'w')
f.write(json_data)
f.close()


