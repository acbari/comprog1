import json,xmltodict
        
with open('flowerandbg.xml') as inFh:
	with open('flowerandbg.json','w') as outFh:
		json.dump(xmltodict.parse(inFh.read()), outFh)

import xmlplain
import yaml
		
# Read to plain object
with open("flowerandbg.xml") as inf:
	root = xmlplain.xml_to_obj(inf, strip_space=True, fold_dict=True)
		
# Output plain YAML
with open("flowerandbg.yml", "w") as outf:
	xmlplain.obj_to_yaml(root, outf)