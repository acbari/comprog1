# Program to convert an xml 
# file to json file 

# import json module and xmltodict 
# module provided by python 
import xmltodict 
import yaml


# open the input xml file and read 
# data in form of python dictionary 
# using xmltodict module 
with open("basic.xml") as xml_file: 
	
	data_dict = xmltodict.parse(xml_file.read()) 
	xml_file.close() 
	
	# generate the object using json.dumps() 
	# corresponding to json data 
	
	yaml_data = yaml.dump(data_dict) 
	print(yaml_data)
	# Write the json data to output 
	# json file 
	
	#?????
	#untuk menyimpan ke dalam format yaml caranya sama halnya menyimpan data ke dalam format text
	with open("data.yaml", "w") as yaml_file: 
		yaml_file.write(yaml_data) 
		yaml_file.close() 
	