import json
import xmltodict
 
with open("sample.xml", 'r') as f:
    xmlString = f.read()
 
print("XML input (sample.xml):")
print(xmlString)
     
jsonString = json.dumps(xmltodict.parse(xmlString), indent=4)
 
print("\nJSON output(output.json):")
print(jsonString)
 
with open("output.json", 'w') as f:
    f.write(jsonString)
    
import yaml

f = open("sample.xml").read()
a = xmltodict.parse(f)
yaml.dump(a, open("out.yaml",'w'))

#kode program di bawah tidak diperlukan
#baris kode 22 sudah menghasilkan format yaml dan menyimpannya ke dalam file out.yaml
f = open ("sample.xml","r")
xmlstr = f.read()
f.close()
randDict = xmltodict.parse(xmlstr)
yaml_str = yaml.dump(randDict)
print(yaml_str)